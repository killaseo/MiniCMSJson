<?php
declare(strict_types=1); session_start();
$config = require dirname(__DIR__) . '/config.php';
require dirname(__DIR__) . '/core/Slugger.php'; require dirname(__DIR__) . '/core/JsonCms.php';
$cms = new JsonCms($config); $basePath = rtrim($config['base_path'] ?? '', '/');
function admin_url(string $path=''): string { global $basePath; return $basePath . '/admin/' . ltrim($path,'/'); }
function h(string $v): string { return htmlspecialchars($v, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function require_login(): void { if(empty($_SESSION['admin_logged'])){ header('Location: '.admin_url('login.php')); exit; } }
function split_lines(string $v): array { $out=[]; foreach(preg_split('/\R/u',$v)?:[] as $l){$l=trim($l); if($l!=='')$out[]=$l;} return $out; }
