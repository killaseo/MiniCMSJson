<?php
declare(strict_types=1);

$config       = require __DIR__ . '/../config.php';
require __DIR__ . '/../core/ThemeManager.php';

$themeManager = new ThemeManager($config);
$message      = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $theme = (string)($_POST['theme'] ?? '');
    if ($themeManager->setActiveTheme($theme)) {
        $message = 'Motyw został zmieniony.';
    } else {
        $message = 'Nie udało się zmienić motywu. Sprawdź uprawnienia zapisu lub czy plik CSS istnieje.';
    }
}

$active = $themeManager->getActiveThemeId();
$themes = $themeManager->getAvailableThemes();

function h(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function previewStyle(array $preview, string $part): string {
    if ($part === 'primary') {
        $bg = $preview['primary'] ?? '#e8e8e8';
        return 'background:' . h($bg);
    }
    if ($part === 'accent') {
        $bg = $preview['accent'] ?? '#aaaaaa';
        return 'background:' . h($bg);
    }
    return '';
}
?>
<!doctype html>
<html lang="pl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin — wybór motywu</title>
<style>
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#111;color:#f5f5f5;line-height:1.55}
main{max-width:1040px;margin:auto;padding:clamp(1rem,4vw,3rem)}
a{color:#fff}
.top{display:flex;justify-content:space-between;gap:1rem;align-items:flex-start;margin-bottom:2rem;flex-wrap:wrap}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:1rem}
.card{background:#1d1d1d;border:1px solid #333;border-radius:24px;padding:1.2rem;box-shadow:0 20px 60px rgba(0,0,0,.25);cursor:pointer}
.card.active{border-color:#9cffc7;box-shadow:0 0 0 3px rgba(156,255,199,.15)}
.card input[type=radio]{position:absolute;opacity:0;width:0;height:0}
.badge{display:inline-flex;border:1px solid #444;border-radius:999px;padding:.25rem .6rem;color:#aaa;font-size:.82rem}
button{cursor:pointer;border:0;border-radius:999px;padding:.7rem 1.4rem;font-weight:800;background:#9cffc7;color:#111;margin-top:1.5rem;font-size:1rem}
button:hover{filter:brightness(.9)}
.notice{background:#253525;border:1px solid #4f885d;border-radius:18px;padding:1rem;margin:1rem 0}
.notice.err{background:#352525;border-color:#885d5d}
.preview{height:110px;border-radius:18px;margin:1rem 0;border:1px solid rgba(255,255,255,.12);overflow:hidden;display:grid;grid-template-columns:1fr 1.25fr}
.preview span{display:block;height:100%}
code{background:#222;padding:.15rem .35rem;border-radius:.35rem;font-size:.85rem}
h2{margin:.5rem 0 .25rem;font-size:1.05rem}
.hint{color:#888;font-size:.85rem;margin:.25rem 0 .5rem}
.how-to{background:#1a1a1a;border:1px solid #2a2a2a;border-radius:18px;padding:1.2rem;margin-top:2.5rem}
.how-to h3{margin-top:0;color:#9cffc7}
.how-to ol{margin:.5rem 0 0;padding-left:1.25rem;color:#ccc}
.how-to li{margin:.35rem 0}
</style>
</head>
<body>
<main>
    <div class="top">
        <div>
            <p class="badge">JSON AI CMS — Admin</p>
            <h1>Wybór motywu strony</h1>
            <p>Aktywny motyw zapisywany jest w <code>content/theme.json</code>.<br>
            Dostępne motywy wykrywane są automatycznie z katalogu <code>public/assets/themes/</code>.</p>
        </div>
        <a href="/">← Wróć na stronę</a>
    </div>

    <?php if ($message): ?>
        <div class="notice <?= str_contains($message, 'Nie udało') ? 'err' : '' ?>"><?= h($message) ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="grid">
            <?php foreach ($themes as $theme): ?>
                <?php
                    $id       = (string)($theme['id'] ?? '');
                    $preview  = (array)($theme['preview'] ?? []);
                    $isActive = $id === $active;
                ?>
                <label class="card <?= $isActive ? 'active' : '' ?>">
                    <input type="radio" name="theme" value="<?= h($id) ?>" <?= $isActive ? 'checked' : '' ?>>
                    <div class="preview">
                        <span style="<?= previewStyle($preview, 'primary') ?>"></span>
                        <span style="<?= previewStyle($preview, 'accent') ?>"></span>
                    </div>
                    <h2><?= h((string)($theme['name'] ?? $id)) ?></h2>
                    <p class="hint"><?= h((string)($theme['description'] ?? '')) ?></p>
                    <?php if ($isActive): ?>
                        <p class="badge">✓ aktywny</p>
                    <?php endif; ?>
                </label>
            <?php endforeach; ?>
        </div>
        <button type="submit">Zapisz motyw</button>
    </form>

    <div class="how-to">
        <h3>Jak dodać nowy motyw?</h3>
        <ol>
            <li>Wrzuć plik <code>public/assets/themes/<strong>nazwa</strong>.css</code> — style nadpisujące bazowy <code>style.css</code></li>
            <li>Wrzuć plik <code>public/assets/themes/<strong>nazwa</strong>.json</code> — metadane motywu (nazwa, opis, kolory podglądu)</li>
            <li>Gotowe — motyw pojawi się automatycznie na tej stronie</li>
        </ol>
        <p style="color:#888;font-size:.85rem;margin-bottom:0">
            Format JSON: <code>{"name":"…","description":"…","preview":{"primary":"#hex","accent":"#hex"}}</code>
        </p>
    </div>
</main>
</body>
</html>
