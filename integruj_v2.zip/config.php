<?php
return [
    'site_url' => 'https://gdzieswpolsce.pl',
    'site_name' => 'Gdzieś w Polsce',
    'base_path' => '',
    'default_root' => 'ai',
    'content_dir' => __DIR__ . '/content',
    'cache_dir' => __DIR__ . '/content/cache',
    'public_assets' => '/public/assets',
    'themes_dir' => __DIR__ . '/public/assets/themes',
    'debug' => true,
    'public_ai_endpoints' => true,
    'public_md_endpoints' => true,
    'admin_user' => 'admin',
    'admin_password' => 'zmien-to-haslo',
];
