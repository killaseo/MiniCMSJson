<?php
declare(strict_types=1);

final class JsonCms
{
    private array $config;
    private string $contentDir;

    public function __construct(array $config)
    {
        $this->config = $config;
        $this->contentDir = rtrim($config['content_dir'], '/');
    }

    public function readJson(string $path): array
    {
        if (!is_file($path)) {
            return [];
        }
        $raw = file_get_contents($path);
        $data = json_decode($raw ?: '', true);
        if (!is_array($data)) {
            if ($this->config['debug']) {
                throw new RuntimeException("Invalid JSON: {$path}");
            }
            return [];
        }
        return $data;
    }

    public function getSite(): array
    {
        return $this->readJson($this->contentDir . '/site.json');
    }

    public function getRoots(): array
    {
        $data = $this->readJson($this->contentDir . '/roots.json');
        return $data['roots'] ?? [];
    }

    public function findRootBySlug(string $slug): ?array
    {
        foreach ($this->getRoots() as $root) {
            if (($root['slug'] ?? '') === $slug) {
                return $root;
            }
        }
        return null;
    }

    public function getPages(): array
    {
        $pages = [];
        foreach (glob($this->contentDir . '/pages/*.json') ?: [] as $file) {
            $page = $this->readJson($file);
            if (!$page) {
                continue;
            }
            $page['_file'] = basename($file);
            $pages[] = $page;
        }

        usort($pages, function ($a, $b) {
            return strcmp($b['updated_at'] ?? '', $a['updated_at'] ?? '');
        });

        return $pages;
    }

    public function getPublishedPages(): array
    {
        return array_values(array_filter($this->getPages(), fn($p) => ($p['status'] ?? 'draft') === 'published'));
    }

    public function getPagesByRoot(string $rootId): array
    {
        return array_values(array_filter($this->getPublishedPages(), fn($p) => ($p['root'] ?? '') === $rootId));
    }

    public function findPageBySlug(string $slug): ?array
    {
        $slug = trim($slug, '/');
        foreach ($this->getPublishedPages() as $page) {
            if (($page['slug'] ?? '') === $slug) {
                return $page;
            }
            if (($page['route']['path'] ?? '') === '/' . $slug) {
                return $page;
            }
        }
        return null;
    }

    public function getTemplate(string $templateName): array
    {
        $safe = preg_replace('/[^a-zA-Z0-9_-]/', '', $templateName);
        $template = $this->readJson($this->contentDir . '/templates/' . $safe . '.json');
        if (!$template) {
            $template = $this->readJson($this->contentDir . '/templates/default.json');
        }
        return $template;
    }


    /**
     * Auto-discovery szablonów — skanuje content/templates/*.json
     */
    public function getTemplates(): array
    {
        $templates = [];
        foreach (glob($this->contentDir . '/templates/*.json') ?: [] as $file) {
            $t = $this->readJson($file);
            if (!empty($t['id'])) {
                $templates[] = $t;
            }
        }
        usort($templates, fn($a, $b) => strcmp((string)($a['id'] ?? ''), (string)($b['id'] ?? '')));
        return $templates;
    }

    public function toAiDocument(array $page): array
    {
        $blocksText = [];
        foreach (($page['content'] ?? []) as $block) {
            $blocksText[] = $this->blockToPlainText($block);
        }

        return [
            'id' => $page['id'] ?? null,
            'slug' => $page['slug'] ?? null,
            'url' => rtrim($this->config['site_url'], '/') . '/' . ltrim($page['slug'] ?? '', '/'),
            'title' => $page['title'] ?? '',
            'description' => $page['description'] ?? '',
            'root' => $page['root'] ?? null,
            'type' => $page['type'] ?? 'post',
            'status' => $page['status'] ?? 'published',
            'updated_at' => $page['updated_at'] ?? null,
            'ai' => $page['ai'] ?? [],
            'entities' => $page['entities'] ?? [],
            'questions' => $page['questions'] ?? [],
            'summary' => $page['ai']['summary'] ?? $page['description'] ?? '',
            'key_points' => $page['ai']['key_points'] ?? [],
            'content_plain' => trim(implode("\n\n", array_filter($blocksText))),
            'content_blocks' => $page['content'] ?? [],
        ];
    }

    public function buildAiIndex(): array
    {
        $items = [];
        foreach ($this->getPublishedPages() as $page) {
            $items[] = [
                'title' => $page['title'] ?? '',
                'url' => rtrim($this->config['site_url'], '/') . '/' . ($page['slug'] ?? ''),
                'ai_url' => rtrim($this->config['site_url'], '/') . '/_ai/' . ($page['slug'] ?? '') . '.json',
                'md_url' => rtrim($this->config['site_url'], '/') . '/_md/' . ($page['slug'] ?? '') . '.md',
                'summary' => $page['ai']['summary'] ?? $page['description'] ?? '',
                'root' => $page['root'] ?? null,
                'updated_at' => $page['updated_at'] ?? null,
            ];
        }

        return [
            'site' => $this->getSite(),
            'roots' => $this->getRoots(),
            'items' => $items,
        ];
    }

    public function buildLlmsTxt(): string
    {
        $site = $this->getSite();
        $out = [];
        $out[] = '# ' . ($site['name'] ?? $this->config['site_name']);
        $out[] = '';
        $out[] = $site['description'] ?? '';
        $out[] = '';
        $out[] = '## Main AI index';
        $out[] = rtrim($this->config['site_url'], '/') . '/_ai';
        $out[] = '';
        $out[] = '## Posts';

        foreach ($this->getPublishedPages() as $page) {
            $title = $page['title'] ?? $page['slug'];
            $summary = $page['ai']['summary'] ?? $page['description'] ?? '';
            $out[] = '- [' . $title . '](' . rtrim($this->config['site_url'], '/') . '/' . ($page['slug'] ?? '') . '): ' . $summary;
            $out[] = '  - JSON: ' . rtrim($this->config['site_url'], '/') . '/_ai/' . ($page['slug'] ?? '') . '.json';
            $out[] = '  - Markdown: ' . rtrim($this->config['site_url'], '/') . '/_md/' . ($page['slug'] ?? '') . '.md';
        }

        return trim(implode("\n", $out)) . "\n";
    }

    public function buildSitemapXml(): string
    {
        $base = rtrim($this->config['site_url'], '/');
        $urls = [];
        $urls[] = ['loc' => $base . '/', 'lastmod' => date('Y-m-d')];

        foreach ($this->getRoots() as $root) {
            $urls[] = ['loc' => $base . '/' . ($root['slug'] ?? ''), 'lastmod' => date('Y-m-d')];
        }

        foreach ($this->getPublishedPages() as $page) {
            $urls[] = [
                'loc' => $base . '/' . ($page['slug'] ?? ''),
                'lastmod' => substr($page['updated_at'] ?? date('Y-m-d'), 0, 10),
            ];
        }

        $xml = [];
        $xml[] = '<?xml version="1.0" encoding="UTF-8"?>';
        $xml[] = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        foreach ($urls as $u) {
            $xml[] = '  <url>';
            $xml[] = '    <loc>' . htmlspecialchars($u['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</loc>';
            $xml[] = '    <lastmod>' . htmlspecialchars($u['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8') . '</lastmod>';
            $xml[] = '  </url>';
        }
        $xml[] = '</urlset>';

        return implode("\n", $xml);
    }

    private function blockToPlainText(array $block): string
    {
        foreach ($block as $type => $value) {
            if (is_string($value)) {
                return $value;
            }
            if ($type === 'qa' && is_array($value)) {
                return 'Pytanie: ' . ($value['q'] ?? '') . "\nOdpowiedź: " . ($value['a'] ?? '');
            }
            if ($type === 'list' && is_array($value)) {
                return implode("\n", array_map(fn($i) => '- ' . (is_string($i) ? $i : json_encode($i, JSON_UNESCAPED_UNICODE)), $value));
            }
            if ($type === 'cards' && is_array($value)) {
                return implode("\n\n", array_map(function ($card) {
                    return ($card['title'] ?? '') . "\n" . ($card['text'] ?? '');
                }, $value));
            }
        }
        return '';
    }
}
