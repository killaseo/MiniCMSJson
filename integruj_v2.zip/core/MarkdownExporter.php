<?php
declare(strict_types=1);

final class MarkdownExporter
{
    public function pageToMarkdown(array $page): string
    {
        $out = [];
        $out[] = '# ' . ($page['title'] ?? '');
        $out[] = '';
        if (!empty($page['description'])) {
            $out[] = '> ' . $page['description'];
            $out[] = '';
        }

        foreach (($page['content'] ?? []) as $block) {
            $out[] = $this->blockToMarkdown($block);
            $out[] = '';
        }

        if (!empty($page['ai']['key_points'])) {
            $out[] = '## Kluczowe punkty';
            foreach ($page['ai']['key_points'] as $point) {
                $out[] = '- ' . $point;
            }
            $out[] = '';
        }

        if (!empty($page['questions'])) {
            $out[] = '## Pytania';
            foreach ($page['questions'] as $q) {
                $out[] = '- ' . $q;
            }
            $out[] = '';
        }

        return trim(implode("\n", $out)) . "\n";
    }

    private function blockToMarkdown(array $block): string
    {
        foreach ($block as $type => $value) {
            switch ($type) {
                case 'lead':
                    return '> ' . (string)$value;
                case 'h2':
                    return '## ' . (string)$value;
                case 'h3':
                    return '### ' . (string)$value;
                case 'p':
                    return (string)$value;
                case 'note':
                    return '> **Nota:** ' . (string)$value;
                case 'quote':
                    return '> ' . (string)$value;
                case 'list':
                    return implode("\n", array_map(fn($i) => '- ' . (string)$i, (array)$value));
                case 'qa':
                    $q = is_array($value) ? ($value['q'] ?? '') : '';
                    $a = is_array($value) ? ($value['a'] ?? '') : '';
                    return '### ' . $q . "\n\n" . $a;
                case 'cards':
                    $out = [];
                    foreach ((array)$value as $card) {
                        $out[] = '### ' . ($card['title'] ?? '');
                        $out[] = '';
                        $out[] = $card['text'] ?? '';
                        $out[] = '';
                    }
                    return trim(implode("\n", $out));
                case 'html':
                    return '';
            }
        }
        return '';
    }
}
