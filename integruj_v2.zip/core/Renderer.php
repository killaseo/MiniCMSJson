<?php
declare(strict_types=1);

final class Renderer
{
    private array  $config;
    private string $theme    = 'classic';
    private string $basePath;

    // Ścieżka do katalogu themes/ na dysku (do inlinowania CSS)
    private string $themesDir;

    public function __construct(array $config)
    {
        $this->config    = $config;
        $this->basePath  = rtrim($config['base_path'] ?? '', '/');
        $this->themesDir = rtrim(
            $config['themes_dir'] ?? (dirname(__DIR__) . '/public/assets/themes'),
            '/'
        );
    }

    public function setTheme(string $theme): void
    {
        $theme = strtolower($theme);
        $this->theme = preg_replace('/[^a-z0-9_-]/', '', $theme) ?: 'classic';
    }

    private function e(string $v): string
    {
        return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    private function url(string $p): string
    {
        return $this->basePath . '/' . ltrim($p, '/');
    }

    // ─── Inline CSS motywu ────────────────────────────────────────────────
    // Zamiast <link> do pliku theme.css → <style> inlined w <head>.
    // Eliminuje drugi request i render-blocking chain: HTML → style.css → theme.css
    private function inlineThemeCss(): string
    {
        $file = $this->themesDir . '/' . $this->theme . '.css';
        if (!is_file($file)) {
            return '';
        }
        $css = file_get_contents($file);
        if ($css === false || trim($css) === '') {
            return '';
        }
        // Miniminalizacja: usuń komentarze blokowe i nadmiarowe białe znaki
        $css = preg_replace('#/\*.*?\*/#s', '', $css);
        $css = preg_replace('/\s+/', ' ', $css);
        $css = trim($css);
        return '<style id="theme-' . $this->e($this->theme) . '">' . $css . '</style>';
    }

    // ─── Render metody ────────────────────────────────────────────────────

    public function renderHome(array $roots, array $pages): string
    {
        $cards = '';
        foreach ($roots as $r) {
            $cards .= '<a class="card" href="' . $this->url($r['slug'] ?? '') . '">'
                . '<strong>' . $this->e($r['title'] ?? '') . '</strong>'
                . '<span>' . $this->e($r['description'] ?? '') . '</span></a>';
        }
        $latest = '';
        foreach (array_slice($pages, 0, 12) as $p) {
            $latest .= '<li><a href="' . $this->url($p['slug'] ?? '') . '">'
                . $this->e($p['title'] ?? '') . '</a>'
                . '<small>' . $this->e($p['description'] ?? '') . '</small></li>';
        }
        return $this->layout([
            'title'       => $this->config['site_name'],
            'description' => 'Gdzieś w Polsce',
            'body'        => '<section class="hero">'
                . '<p class="eyebrow">JSON-first / AI-ready / multi-root</p>'
                . '<h1>' . $this->e($this->config['site_name']) . '</h1>'
                . '<p>Treść, układ strony, szablony i dane dla AI siedzą w JSON.</p>'
                . '</section>'
                . '<section><h2>kategorie</h2><div class="grid">' . $cards . '</div></section>'
                . '<section><h2>Najnowsze posty</h2><ul class="post-list">' . $latest . '</ul></section>',
        ]);
    }

    public function renderRoot(array $root, array $pages): string
    {
        $items = '';
        foreach ($pages as $p) {
            $items .= '<li><a href="' . $this->url($p['slug'] ?? '') . '">'
                . $this->e($p['title'] ?? '') . '</a>'
                . '<small>' . $this->e($p['description'] ?? '') . '</small></li>';
        }
        return $this->layout([
            'title'       => $root['title'] ?? '',
            'description' => $root['description'] ?? '',
            'body'        => '<section class="hero small">'
                . '<p class="eyebrow">kategoria</p>'
                . '<h1>' . $this->e($root['title'] ?? '') . '</h1>'
                . '<p>' . $this->e($root['description'] ?? '') . '</p>'
                . '</section>'
                . '<section><h2>Posty</h2><ul class="post-list">' . $items . '</ul></section>',
        ]);
    }

    public function renderPage(array $page): string
    {
        $body = '<article class="article">'
            . '<header class="article-header">'
            . '<p class="eyebrow">' . $this->e($page['root'] ?? 'post') . '</p>'
            . '<h1>' . $this->e($page['title'] ?? '') . '</h1>'
            . '<p class="lead">' . $this->e($page['description'] ?? '') . '</p>'
            . '<div class="machine-links">'
            . '<a href="' . $this->url('/_ai/' . ($page['slug'] ?? '') . '.json') . '">AI JSON</a>'
            . '<a href="' . $this->url('/_md/' . ($page['slug'] ?? '') . '.md') . '">Markdown</a>'
            . '</div></header>';

        if (!empty($page['modules'])) {
            foreach ($page['modules'] as $m) {
                $body .= $this->renderModule($m);
            }
        }
        foreach (($page['content'] ?? []) as $b) {
            $body .= $this->renderBlock($b);
        }
        if (!empty($page['questions'])) {
            $body .= '<section class="faq"><h2>Pytania, na które odpowiada ten tekst</h2>';
            foreach ($page['questions'] as $q) {
                $body .= '<p class="question">' . $this->e((string)$q) . '</p>';
            }
            $body .= '</section>';
        }
        if (!empty($page['sources'])) {
            $body .= '<section class="sources"><h2>Źródła i punkty odniesienia</h2><ul>';
            foreach ($page['sources'] as $s) {
                $body .= '<li><a href="' . $this->e($s['url'] ?? '') . '" rel="nofollow noopener">'
                    . $this->e($s['name'] ?? '') . '</a>'
                    . (!empty($s['checked']) ? ' — sprawdzono: ' . $this->e($s['checked']) : '')
                    . '</li>';
            }
            $body .= '</ul></section>';
        }
        $body .= '</article>';

        return $this->layout([
            'title'       => $page['seo']['title']       ?? $page['title']       ?? '',
            'description' => $page['seo']['description'] ?? $page['description'] ?? '',
            'robots'      => $page['seo']['robots']      ?? 'index,follow',
            'schema'      => $this->buildSchemaJsonLd($page),
            'body'        => $body,
        ]);
    }

    private function renderModule(array $m): string
    {
        $h = '<section class="module" data-module="' . $this->e($m['id'] ?? '') . '">';
        if (!empty($m['label'])) {
            $h .= '<p class="module-label">' . $this->e($m['label']) . '</p>';
        }
        $h .= '<h2>' . $this->e($m['title'] ?? '') . '</h2>'
            . '<p>' . nl2br($this->e($m['body'] ?? '')) . '</p>';
        if (!empty($m['seo_note']) || !empty($m['geo_note'])) {
            $h .= '<div class="notes">';
            if (!empty($m['seo_note'])) {
                $h .= '<p><strong>SEO:</strong> ' . $this->e($m['seo_note']) . '</p>';
            }
            if (!empty($m['geo_note'])) {
                $h .= '<p><strong>GEO/AI:</strong> ' . $this->e($m['geo_note']) . '</p>';
            }
            $h .= '</div>';
        }
        return $h . '</section>';
    }

    private function renderBlock(array $block): string
    {
        foreach ($block as $t => $v) {
            switch ($t) {
                case 'lead':   return '<p class="lead-block">'    . $this->e((string)$v) . '</p>';
                case 'h2':     return '<h2>'                      . $this->e((string)$v) . '</h2>';
                case 'h3':     return '<h3>'                      . $this->e((string)$v) . '</h3>';
                case 'p':      return '<p>'                       . $this->e((string)$v) . '</p>';
                case 'note':   return '<aside class="note">'      . $this->e((string)$v) . '</aside>';
                case 'quote':  return '<blockquote>'              . $this->e((string)$v) . '</blockquote>';
                case 'html':   return (string)$v;
                case 'list':
                    $items = '';
                    foreach ((array)$v as $i) {
                        $items .= '<li>' . $this->e((string)$i) . '</li>';
                    }
                    return '<ul>' . $items . '</ul>';
                case 'qa':
                    return '<section class="qa">'
                        . '<h3>' . $this->e($v['q'] ?? '') . '</h3>'
                        . '<p>'  . $this->e($v['a'] ?? '') . '</p>'
                        . '</section>';
            }
        }
        return '';
    }

    private function buildSchemaJsonLd(array $page): string
    {
        $s = [
            '@context'        => 'https://schema.org',
            '@type'           => $page['schema']['type'] ?? 'Article',
            'headline'        => $page['title']      ?? '',
            'description'     => $page['description'] ?? '',
            'dateModified'    => $page['updated_at']  ?? null,
            'mainEntityOfPage'=> rtrim($this->config['site_url'], '/') . '/' . ($page['slug'] ?? ''),
        ];
        return '<script type="application/ld+json">'
            . json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            . '</script>';
    }

    // ─── Główny layout ────────────────────────────────────────────────────

    private function layout(array $d): string
    {
        $title   = $this->e($d['title']   ?? $this->config['site_name']);
        $desc    = $this->e($d['description'] ?? '');
        $robots  = $this->e($d['robots']  ?? 'index,follow');

        // style.css jako <link> (jeden request, HTTP cache)
        // CSS motywu inlinowany w <style> — eliminuje render-blocking chain
        $css = '<link rel="stylesheet" href="' . $this->url('/public/assets/style.css') . '">'
             . $this->inlineThemeCss();

        return '<!doctype html>'
            . '<html lang="pl"><head>'
            . '<meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width, initial-scale=1">'
            . '<title>' . $title . '</title>'
            . '<meta name="description" content="' . $desc . '">'
            . '<meta name="robots" content="' . $robots . '">'
            . $css
            . ($d['schema'] ?? '')
            . '</head>'
            . '<body class="theme-' . $this->e($this->theme) . '">'
            . '<header class="topbar">'
            . '<a class="logo" href="' . $this->url('/') . '">' . $this->e($this->config['site_name']) . '</a>'
            . '<nav>'
            . '<a href="' . $this->url('/admin/') . '">admin</a>'
            . '<a href="' . $this->url('/llms.txt') . '">llms.txt</a>'
            . '<a href="' . $this->url('/_ai') . '">AI index</a>'
            . '<a href="' . $this->url('/sitemap.xml') . '">sitemap</a>'
            . '</nav></header>'
            . '<main>' . ($d['body'] ?? '') . '</main>'
            . '<footer><p>MiniCMS powered by killaseo.pl</p></footer>'
            . '</body></html>';
    }

    public function render404(string $uri): string
    {
        return $this->layout([
            'title'       => '404',
            'description' => 'Nie znaleziono strony',
            'robots'      => 'noindex,follow',
            'body'        => '<section class="hero small"><h1>404</h1><p>Nie znaleziono: '
                . $this->e($uri) . '</p></section>',
        ]);
    }
}
