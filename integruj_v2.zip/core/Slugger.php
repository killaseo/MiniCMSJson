<?php
declare(strict_types=1);
final class Slugger {
    public static function slug(string $text): string {
        $text = trim(mb_strtolower($text, 'UTF-8'));
        $text = strtr($text, ['ą'=>'a','ć'=>'c','ę'=>'e','ł'=>'l','ń'=>'n','ó'=>'o','ś'=>'s','ź'=>'z','ż'=>'z']);
        $text = preg_replace('/[^a-z0-9]+/u', '-', $text);
        $text = trim($text ?? '', '-');
        return $text !== '' ? $text : 'bez-tytulu';
    }
    public static function uniquePageSlug(string $slug, string $pagesDir, ?string $currentFile = null): string {
        $base = self::slug($slug); $candidate = $base; $i = 2;
        while (true) {
            $file = rtrim($pagesDir, '/') . '/' . $candidate . '.json';
            if (!is_file($file) || ($currentFile && realpath($file) === realpath($currentFile))) return $candidate;
            $candidate = $base . '-' . $i; $i++;
        }
    }
}
