<?php
declare(strict_types=1);

/**
 * ThemeManager — auto-discovery motywów.
 *
 * Jak dodać nowy motyw:
 *   1. Wrzuć plik CSS do  public/assets/themes/{id}.css
 *   2. Wrzuć plik JSON do public/assets/themes/{id}.json  (metadane)
 *   3. Gotowe — motyw pojawia się automatycznie w panelu /admin/theme.php
 *
 * Format {id}.json:
 * {
 *   "name": "Nazwa motywu",
 *   "description": "Krótki opis",
 *   "preview": { "primary": "#hex", "accent": "#hex" }
 * }
 */
final class ThemeManager
{
    private array $config;
    private string $themeFile;
    private string $themesDir;

    public function __construct(array $config)
    {
        $this->config    = $config;
        $this->themeFile = rtrim($config['content_dir'], '/') . '/theme.json';
        // Fallback jeśli themes_dir nie ma w config
        $this->themesDir = rtrim(
            $config['themes_dir'] ?? (dirname(__DIR__) . '/public/assets/themes'),
            '/'
        );
    }

    // ─── Odczyt stanu aktywnego motywu ─────────────────────────────────────

    public function getThemeConfig(): array
    {
        if (!is_file($this->themeFile)) {
            return ['active' => 'classic'];
        }
        $raw  = file_get_contents($this->themeFile);
        $data = json_decode($raw ?: '', true);
        return is_array($data) ? $data : ['active' => 'classic'];
    }

    public function getActiveThemeId(): string
    {
        $data = $this->getThemeConfig();
        return $this->sanitizeId((string)($data['active'] ?? 'classic'));
    }

    // ─── Auto-discovery ────────────────────────────────────────────────────

    /**
     * Skanuje katalog themes/ — każdy plik *.css to osobny motyw.
     * Metadane pobierane z companion *.json (opcjonalny).
     */
    public function getAvailableThemes(): array
    {
        $themes   = [];
        $cssFiles = glob($this->themesDir . '/*.css') ?: [];
        sort($cssFiles);

        foreach ($cssFiles as $cssFile) {
            $id = $this->sanitizeId(basename($cssFile, '.css'));
            if (!$id) {
                continue;
            }

            $meta     = $this->readThemeMeta($id);
            $themes[] = [
                'id'          => $id,
                'name'        => (string)($meta['name']        ?? ucfirst($id)),
                'description' => (string)($meta['description'] ?? ''),
                'preview'     => is_array($meta['preview'] ?? null) ? $meta['preview'] : [],
            ];
        }

        return $themes;
    }

    /**
     * Motyw jest dozwolony gdy istnieje jego plik CSS.
     * Nie wymaga wpisu w theme.json.
     */
    public function isAllowedTheme(string $themeId): bool
    {
        $id = $this->sanitizeId($themeId);
        return is_file($this->themesDir . '/' . $id . '.css');
    }

    // ─── Zapis aktywnego motywu ────────────────────────────────────────────

    public function setActiveTheme(string $themeId): bool
    {
        $id = $this->sanitizeId($themeId);

        if (!$this->isAllowedTheme($id)) {
            return false;
        }

        // Zapisujemy tylko "active" — lista available jest auto-discovery
        $data = ['active' => $id];

        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) {
            return false;
        }

        return file_put_contents($this->themeFile, $json . PHP_EOL, LOCK_EX) !== false;
    }

    // ─── Helpers ───────────────────────────────────────────────────────────

    private function readThemeMeta(string $id): array
    {
        $jsonFile = $this->themesDir . '/' . $id . '.json';
        if (!is_file($jsonFile)) {
            return [];
        }
        $raw  = file_get_contents($jsonFile);
        $data = json_decode($raw ?: '', true);
        return is_array($data) ? $data : [];
    }

    private function sanitizeId(string $id): string
    {
        $id = strtolower($id);
        return preg_replace('/[^a-z0-9_-]/', '', $id) ?: 'classic';
    }
}
