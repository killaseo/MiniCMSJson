<?php
declare(strict_types=1);

$config = require __DIR__ . '/config.php';

require __DIR__ . '/core/Slugger.php';
require __DIR__ . '/core/JsonCms.php';
require __DIR__ . '/core/Renderer.php';
require __DIR__ . '/core/MarkdownExporter.php';
require __DIR__ . '/core/ThemeManager.php';

$cms = new JsonCms($config);
$renderer = new Renderer($config);
$themeManager = new ThemeManager($config);
$renderer->setTheme($themeManager->getActiveThemeId());
$md = new MarkdownExporter();

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$uri = '/' . trim((string)$uri, '/');

$basePath = rtrim($config['base_path'] ?? '', '/');
if ($basePath !== '' && str_starts_with($uri, $basePath)) {
    $uri = substr($uri, strlen($basePath));
    $uri = '/' . trim($uri, '/');
}
if ($uri === '//') { $uri = '/'; }

if ($uri === '/index.php') {
    $uri = '/';
}

// Built-in feeds / machine-readable endpoints.
if ($uri === '/sitemap.xml') {
    header('Content-Type: application/xml; charset=utf-8');
    echo $cms->buildSitemapXml();
    exit;
}

if ($uri === '/llms.txt') {
    header('Content-Type: text/plain; charset=utf-8');
    echo $cms->buildLlmsTxt();
    exit;
}

if ($uri === '/_ai' || $uri === '/_ai/') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($cms->buildAiIndex(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (preg_match('#^/_ai/(.+)\.json$#', $uri, $m)) {
    if (!$config['public_ai_endpoints']) {
        http_response_code(403);
        echo 'AI endpoints disabled';
        exit;
    }
    $page = $cms->findPageBySlug($m[1]);
    if (!$page) {
        http_response_code(404);
        echo 'Not found';
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($cms->toAiDocument($page), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (preg_match('#^/_md/(.+)\.md$#', $uri, $m)) {
    if (!$config['public_md_endpoints']) {
        http_response_code(403);
        echo 'Markdown endpoints disabled';
        exit;
    }
    $page = $cms->findPageBySlug($m[1]);
    if (!$page) {
        http_response_code(404);
        echo 'Not found';
        exit;
    }
    header('Content-Type: text/markdown; charset=utf-8');
    echo $md->pageToMarkdown($page);
    exit;
}

// Homepage.
if ($uri === '/') {
    $roots = $cms->getRoots();
    $pages = $cms->getPublishedPages();
    header('Content-Type: text/html; charset=utf-8');
    echo $renderer->renderHome($roots, $pages);
    exit;
}

// Root/category listing: /ai, /legendy, /seo
$root = $cms->findRootBySlug(trim($uri, '/'));
if ($root) {
    $pages = $cms->getPagesByRoot($root['id']);
    header('Content-Type: text/html; charset=utf-8');
    echo $renderer->renderRoot($root, $pages);
    exit;
}

// Page route: /slug
$page = $cms->findPageBySlug(trim($uri, '/'));
if ($page) {
    header('Content-Type: text/html; charset=utf-8');
    echo $renderer->renderPage($page);
    exit;
}

http_response_code(404);
header('Content-Type: text/html; charset=utf-8');
echo $renderer->render404($uri);
